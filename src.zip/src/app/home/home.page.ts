import { Component, ViewChild } from '@angular/core';
import { ColumnMode, SelectionType } from '@swimlane/ngx-datatable';
import { DatatableComponent } from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  
})

export class HomePage {
public pepperoni:boolean = true;
public sausage:boolean = true;
public mushrooms:boolean = true;
selected = [];
temp = [];
reorderable = true;

ColumnMode = ColumnMode;
columns = [{ prop: 'Name' }, { name: 'Age' }, { name: 'Gender' }];

@ViewChild(DatatableComponent, { static: false }) table: DatatableComponent;

  SelectionType = SelectionType;
  rows = [
    {
  
      "name": "Priya",
      "gender": "female",
      "age": 22,
      "emailId": "pkochar100@gmail.com"
    },
    {
      "name": "Sakshi",
      "gender": "female",
      "age": 33,
      "emailId": "sakshi100@gmail.com"
    },
    {
      "name": "Reena",
      "gender": "female",
      "age": 65,
      "emailId": "reena100@gmail.com"
    },
    {
      "name": "Anjai getting good",
      "gender": "female",
      "age": 44,
      "emailId": "anjali100@gmail.com"

    },
    {
      "name": "Devyani",
      "gender": "female",
      "age": 25,
      "emailId": "devyani100@gmail.com"
    },
    {
      "name": "Sakshi",
      "gender": "female",
      "age": 65,
      "emailId": "sakshi100@gmail.com"
    },
    {
      "name": "Namrata",
      "gender": "female",
      "age": 65,
      "emailId": "namrata100@gmail.com"
    },
    {
      "name": "Astha",
      "gender": "female",
      "age": 65,
      "emailId": "astha100@gmail.com"
    },
    {
      "name": "Riya",
      "gender": "female",
      "age": 65,
      "emailId": "riya100@gmail.com"
    },
    {
      "name": "Sushmita",
      "gender": "female",
      "age": 65,
      "emailId": "sushmita100@gmail.com"
    },
    {
      "name": "saksham",
      "gender": "Male",
      "age": 45,
      "emailId": "saksham100@gmail.com"
    },
    {
      "name": "Narayan",
      "gender": "Male",
      "age": 34,
      "emailId": "narayan100@gmail.com"
    },
    {
      "name": "Deepak",
      "gender": "Male",
      "age": 56,
      "emailId": "deepak100@gmail.com"
    },
    {
      "name": "Karan",
      "gender": "Male",
      "age": 65,
      "emailId": "karan100@gmail.com"
    },
    {
      "name": "Royale",
      "gender": "Male",
      "age": 56,
      "emailId": "royale100@gmail.com"
    },
    {
      "name": "Akash",
      "gender": "Male",
      "age": 23,
      "emailId": "akas100@gmail.com"
    }
  ];
  
  tablestyle = 'bootstrap';
  
  constructor() {
    this.fetch(data => {
      // cache our list
      this.temp = [...data];

      // push our inital complete list
      this.rows = data;
    });
  }

  fetch(cb) {
    const req = new XMLHttpRequest();
    req.open('GET', `assets/data/company.json`);

    req.onload = () => {
      cb(JSON.parse(req.response));
    };

    req.send();
  }

    
    onSelect({ selected }) {
      console.log('Select Event', selected, this.selected);
  
      this.selected.splice(0, this.selected.length);
      this.selected.push(...selected);
    }
  
    onActivate(event) {
      console.log('Activate Event', event);
    }
  
    displayCheck(row) {
      return row.name !== 'Ethel Price';
    }
  
  
    switchStyle(){
      if (this.tablestyle == 'dark'){
        this.tablestyle = 'bootstrap'
      } else {
        this.tablestyle = 'dark';
      }
    }

    updateFilter(event) {
      const val = event.target.value.toLowerCase();
  
      // filter our data
      const temp = this.temp.filter(function(d) {
        return d.name.toLowerCase().indexOf(val) !== -1 || !val;
      });
     // update the rows
     this.rows = temp;
     // Whenever the filter changes, always go back to the first page
     this.table.offset = 0;
   }

}
   
  


